#include "guidummy.h"

GuiDummy::GuiDummy() {}

void GuiDummy::showSplashScreen() {}

void GuiDummy::hideSplashScreen() {}

void GuiDummy::splashShowMessage(const QString & /*msg*/) {}

void GuiDummy::showSetting() {}

void GuiDummy::showMainWindow() {}

void GuiDummy::showRestartError(const QString & /*title*/, const QString & /*msg*/) {}

void GuiDummy::guiMessage(int /*id*/, const QString & /*str*/) {}

void GuiDummy::setSettingSocketOpenClose(std::function<void(const QString &, int)> /*openCon*/,
                                         std::function<void()> /*closeCon*/) {}
