CREATE TABLE configs (
	`id` INT NOT NULL,
    `value` TEXT NULL,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB;
