CREATE TABLE configs (
	`id` INTEGER PRIMARY KEY,
    `value` TEXT NULL
);
