CREATE INDEX BANKDELETED ON banks (deleted_at);
-- separator
CREATE INDEX CATEGORYDELETED ON categories (deleted_at);
-- separator
CREATE INDEX CUSTOMERDELETED ON customers (deleted_at);
-- separator
CREATE INDEX ITEMDELETED ON items (deleted_at);
-- separator
CREATE INDEX MACHINEDELETED ON machines (deleted_at);
-- separator
CREATE INDEX SUPLIERDELETED ON supliers (deleted_at);
-- separator
CREATE INDEX USERDELETED ON users (deleted_at);